package ru.perm.v.webclienttest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebclientTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebclientTestApplication.class, args);
	}

}
